// cPanel Node.js Entry Point
// This file is required by cPanel Node.js applications

import('./src/server.js')
  .then(() => {
    console.log('BlockCoop M-Pesa Backend started successfully');
  })
  .catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
