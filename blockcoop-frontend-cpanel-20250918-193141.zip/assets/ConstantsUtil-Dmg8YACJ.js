const s=/[.*+?^${}()|[\]\\]/gu,e=/[0-9,.]/u,t="https://reown.com";export{t as R,e as n,s};
